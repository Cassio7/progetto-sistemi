# Eseguire il file start.sh 
